#!/bin/bash
# common function for unit test
# @author mnstory.net
# @version 1.0 - 20160723

shopt -s expand_aliases
SCRIPTDIR=$(dirname $(realpath $0 2>/dev/null) 2>/dev/null)
SCRIPT_NAME=$(basename $(realpath $0 2>/dev/null) 2>/dev/null)

STATUS_OK="\033[01;32m [*] \033[00m"
STATUS_FAILED="\033[01;31m [x] \033[00m"
STATUS_WARN="\033[01;35m [!] \033[00m"
LOGLEVEL=0

status_ok_cnt=0
status_failed_cnt=0
status_warn_cnt=0

status_info()
{
    local module="$SCRIPT_NAME"
    if [ "$SCRIPT_NAME" == "test" ]; then
        module=$(basename "$SCRIPTDIR")
    fi
    local lasterr=0
    if [ 0 -ne $status_failed_cnt -o 0 -ne $status_warn_cnt ]; then
        echo -en "\033[5m\033[1m\033[01;31m$module\033[00m"
        lasterr=2
    else
        echo -en "\033[01;36m\033[1m$module\033[00m"
    fi
    echo -e " OK \033[01;32m$status_ok_cnt\033[00m FAILED \033[01;31m$status_failed_cnt\033[00m WARN \033[01;35m$status_warn_cnt\033[00m"
    return $lasterr
}

compareSuccess()
{
    local ret_expected="$1"
    local ret_compare="$2"
    local ret_real="$3"
    local target_name="$4"

    shift; shift; shift; shift
    local msg="$@"
    if [ -n "$msg" ]; then
        msg="| $msg"
    fi

    local statusmsg=""
    local checkmsg=""
    local ret_success=""

    if [ "eq" == "$ret_compare" ]; then
        if [ "$ret_expected" == "$ret_real" ]; then
            ret_success="true"
            statusmsg=$STATUS_OK
            checkmsg="return(expect $ret_expected) ok"
        else
            statusmsg=$STATUS_FAILED
            checkmsg="return(expect $ret_expected, real $ret_real) failed"
        fi
    else
        if [ "$ret_expected" != "$ret_real" ]; then
            ret_success="true"
            statusmsg=$STATUS_OK
            checkmsg="return(expect not $ret_expected, real $ret_real) ok"
        else
            statusmsg=$STATUS_FAILED
            checkmsg="return(expect not $ret_expected) failed"
        fi
    fi

    if [ -n "$ret_success" ]; then
        if [ -f "expected/$target_name" ]; then
            if [ -f "out/$target_name" ]; then
                if ! diff "expected/$target_name" "out/$target_name" >/dev/null 2>&1 ; then
                    checkmsg="result not expected"
                    statusmsg=$STATUS_FAILED
                    if [ $LOGLEVEL -ge 1 ]; then
                        diff "expected/$target_name" "out/$target_name" 1>&2
                    fi
                else
                    checkmsg="result matched"
                fi
                #rm -f "out/$target_name"
            else
                checkmsg="output not found"
                statusmsg=$STATUS_WARN
            fi
        fi
    fi

    if [ "$statusmsg" == "$STATUS_FAILED" ]; then
        status_failed_cnt=$(( status_failed_cnt + 1 ))
    elif [ "$statusmsg" == "$STATUS_OK" ]; then
        status_ok_cnt=$(( status_ok_cnt + 1 ))
    elif [ "$statusmsg" == "$STATUS_WARN" ]; then
        status_warn_cnt=$(( status_warn_cnt + 1 ))
    fi
    printf "${statusmsg} %-35s | " "$target_name"
    checkmsg=`printf "%-35s" "$checkmsg"`
    echo -e "\033[1m${checkmsg}\033[00m ${msg}"
}

equalSuccess()
{
    local ret_expected="$1"
    shift
    compareSuccess "$ret_expected" "eq" "$@"
}

notEqualSuccess()
{
    local ret_expected="$1"
    shift
    compareSuccess "$ret_expected" "ne" "$@"
}

alias zeroSuccess='equalSuccess 0'
alias nonZeroSuccess='notEqualSuccess 0'
alias alwaysSuccess='equalSuccess "<empty>" "<empty>"'

main()
{
    if [ "?" == "$1" -o "-h" == "$1" -o "--help" == "$1" ]; then
        echo "$0, unit test for perl module"
        return 1
    fi

    while [ "" != "$1" ]; do
        case "$1" in
            -v* )
                if [ "$1" == "-v" ]; then
                    LOGLEVEL=1
                elif [[ "$1" == "-vv" ]]; then
                    LOGLEVEL=2
                elif [[ "$1" == "-vvv" ]]; then
                    LOGLEVEL=3
                fi
                shift
                ;;
            *)
                break
                ;;
        esac
    done

    entry "$@"
}
export -f main
