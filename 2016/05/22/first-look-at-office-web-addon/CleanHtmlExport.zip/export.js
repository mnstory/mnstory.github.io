

(function () {
    "use strict";
    
    String.prototype.startWith = function(str) {
        var reg=new RegExp("^"+str);
        return reg.test(this);
    }

    String.prototype.endWith = function(str) {
        var reg=new RegExp(str+"$");
        return reg.test(this);
    }

    function notice(type, str) {
        $('#notice').html($("<div class='alert alert-"+type+"' role='alert'></div>").html(str));
    }

    function getEngTitle() {
        var eng_title = $('#eng_title').val();
        if (!eng_title) {
            eng_title = "blog-title";
        }
        return eng_title;
    }

    function getYearMonth() {
        var year_month = $('#year_month').val();
        if (!year_month) {
            var dt = new Date();
            var month = (dt.getMonth()+1);
            year_month = dt.getFullYear()+'/'+(month<10?('0'+month):month);
        }
        return year_month;
    }

    function getBaseURL() {
        return 'http://mnstory.net/wp-content/uploads/' + getYearMonth() +'/' + getEngTitle();
    }

    function getResourceURL() {
        return getBaseURL() +'/res';
    }

    function rPairTag(str, tag, replaceTo) {
        replaceTo = replaceTo || '';
        return str.replace(new RegExp('<'+tag+'[\\s\\S]*?>([\\s\\S]*?)</'+tag+'>', 'gm'), replaceTo);
    }

    function rimg(str) {
        var articalImgVar = getResourceURL() +'/$1';
        return str.replace(new RegExp('<img[\\s\\S]*?src=\".*?\\.files/(.*?)\\..*?\">', 'gm'), '<a rel="'+getEngTitle()+'" class="fancybox" href="'+articalImgVar+'.png" title=""><img src="'+articalImgVar+'.png" class="size-full"></a>');
    }

    function getPdfDownload() {
        return "\n<a target='_bank' href='"+getBaseURL()+'/'+getEngTitle()+".pdf'>PDF下载</a>";
    }

    function generate2() {
        Word.run(function (context) {
            var body = context.document.body;

            // Queue a commmand to get the HTML contents of the body.
            var bodyHTML = body.getHtml();

            // Synchronize the document state by executing the queued commands,
            // and return a promise to indicate task completion.
            return context.sync().then(function () {
                var str = bodyHTML.value+"";
                str = rPairTag(str, 'html', '$1');
                str = rPairTag(str, 'head');
                str = rPairTag(str, 'body', '$1');
                str = rPairTag(str, 'div', '$1');
                str = rPairTag(str, 'p', '$1');
                str = rPairTag(str, 'span', '$1');
                str = rPairTag(str, 'span', '$1');
                str = rimg(str);
                str = jQuery.trim(str);

                str += getPdfDownload();
                $('#message').val(str);
            });
        })
        .catch(function (error) {
            console.log('Error: ' + JSON.stringify(error));
            if (error instanceof OfficeExtension.Error) {
                console.log('Debug info: ' + JSON.stringify(error.debugInfo));
            }
        });
    }
    var str = "";
    function isAllEnglish(t) {
        for (var i = 0; i < t.length; ++i) {
            
            var c = t.charAt(i);
            if (c == '├' || c == '└' || c == '─') {
                continue;
            }
            var ccode = t.charCodeAt(i);
            if (ccode > 255 || ccode < 0) {
                //str += i+"="+t.charAt(i)+"|"+ccode+" is Chinese!\n";
                return false;
            }
        }
        return true;
    }
    
		
    function generate() {
        Word.run(function (context) {
            var paragraphs = context.document.body.paragraphs;

            context.load(paragraphs, 'text, style');

            // Synchronize the document state by executing the queued commands,
            // and return a promise to indicate task completion.
            return context.sync().then(function () {
               
                var block = "";
                var englishLines = 0;
                for(var i = 0; i < paragraphs.items.length; ++i) {
                    var p = paragraphs.items[i]; 
                    var prefix = "";
                    var postfix = "";
                    var cont = p.text;
                    if(0 == p.style.indexOf("标题 ")) {
                        var level = p.style.substr(3);
                        prefix = "<h"+level+">" ;
                        postfix = "</h"+level+">" ;
                    } 
                    else if(0 == p.style.indexOf("列出段落")) {
                        if(cont) {
                            prefix = "<li>" ;
                            postfix = "</li>" ;
                        }
                    } 
                    else if(0 == p.style.indexOf("网格表") || 0 == p.style.indexOf("网格型")) {            
                        if(!cont) {
                            prefix = "</tr>" ;
                            postfix = "<tr>" ;
                        } else {
                            prefix = "<td>" ;
                            postfix = "</td>" ;
                        }                        
                    }
                    else if(0 == p.style.indexOf("题注")) {
                        if(cont) {
                            prefix = "<span class=\"fcaption\">" ;
                            postfix = "</span>" ;
                        }
                    }
                    else if(0 == p.style.indexOf("超链接")) {
                        if(!cont && englishLines==1 && "" != $.trim(block))  {
                            cont = $.trim(block);
                            block = "";
                        }
                        if(cont) {
                            prefix = "<a target=_blank href=\""+cont+"\">";
                            postfix = "</a>" ;
                        }
                    }
                    else {
                        if("正文" != p.style) {
                            str += "========================" + p.style + "->" + cont + "\n";
                            continue;
                        }
                    
                        if(isAllEnglish(p.text)) {
                            ++englishLines;
                            block += cont+"\n";
                            continue;
                        }
                    }
                    
                   /* var ctls = p.contentControls;
                    if(ctls && ctls.items) {
                        for(var j = 0; j < ctls.items.length; ++j) {
                            var ctl = ctls.items[j];
                            str += "ctls[" + i + "][" + j + "] = " + ctl.style + "|" + ctl.tag + "|" + ctl.text;
                        }
                    }*/
                    
                    
                    if(englishLines > 1 || i == (paragraphs.items.length - 1) ) {
                        var lang = "shell";
                        if(0 == block.indexOf("#include") || 0 == block.indexOf("/*") || 0 == block.indexOf("//")) {
                            lang = "c";
                        }
                        
                        if("" != $.trim(block)) {
                            //以前的有内容
                            if(block.endWith("\n\n")) {
                                //最后一行是空行
                                block = block.substr(0, block.length - 2);
                                
                                if(-1 == block.indexOf("\n") && (block.startWith("http://") || block.startWith("https://"))) {
                                    //是一条URL
                                    str += "<a target=_blank href=\""+block+"\">"+block+"</a>\n\n";
                                } else {
                                    //不是URL，可能是多行，用pre的方式
                                    str += "<pre class=\"lang:"+lang+" decode:true\">\n" + block + "\n</pre>\n\n";
                                }
                            } else {
                                //最后一行不是空行，不处理空格情况
                                str += "<pre class=\"lang:"+lang+" decode:true\">\n" + block + "</pre>\n";
                            }
                        } else {
                            //以前的无内容，将空行加上
                            str += block;
                        }
                        str += prefix + cont + postfix + "\n";
                        
                        block = "";
                        englishLines = 0;    
                    } else if(englishLines == 1){
                        str += block + prefix + cont + postfix + "\n";
                        block = "";
                        englishLines = 0;    
                    } else {
                        str += prefix + cont + postfix + "\n";
                    }               
                }
                
                $('#message').val(str);
            });
        })
        .catch(function (error) {
            console.log('Error: ' + JSON.stringify(error));
            if (error instanceof OfficeExtension.Error) {
                console.log('Debug info: ' + JSON.stringify(error.debugInfo));
            }
        });
    }

    Office.initialize = function (reason) {
        $(document).ready(function () {
            // Use this to check whether the API is supported in the Word client.
            if (Office.context.requirements.isSetSupported('WordApi', 1.1)) {
                $('#year_month').val(getYearMonth());
                $('#eng_title').val(getEngTitle());

                $('#generate').click(generate);
                notice('success', 'This code is using Word 2016 or greater.');
            } else {
                notice('warning', 'This code requires Word 2016 or greater.');
            }
        });
    };
})();