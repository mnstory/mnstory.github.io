#!/bin/bash

svn_username="builder"
svn_password="vtbuilder"
svn_baseurl="svn://200.200.0.10/vt/vt"
svn_tmpdir="/tmp/logcheck/"

errecho() 
{
    echo -e "$@" 1>&2
}
export -f errecho

svnexe()
{
	local revision="$1"
	local subcmd="$2"

	local svncmd="svn --non-interactive --no-auth-cache --username $svn_username --password $svn_password -r $revision $subcmd"
	
	#errecho $svncmd
	$svncmd
}

main()
{
	if [ -z "$1" ]; then
		errecho "logcheck.sh \$revision"
		return 1
	fi
	revision="$1"
	

	local svninfo=`svnexe "$revision" "log -v $svn_baseurl/VTP"`
	local paths=`echo "$svninfo" | grep -P '^\s+(A|M)\s+.*(\.pm|\.pl)' | awk '{print $2}'`
	if [ -z "$paths" ]; then
		errecho "can't find new perl file in $revision"
		return 0
	fi

	svn_tmpdir="$svn_tmpdir$$/"
	rm -rf $svn_tmpdir 2>/dev/null
	mkdir -p $svn_tmpdir 2>/dev/null
	for path in $paths; do
		local name=`basename $path`
		name="$svn_tmpdir$name"
		svnexe "$revision" "cat $svn_baseurl$path" > $name
	done
	local checkinfo=`perlcritic -s CodeLayout::RequireLogStatment $svn_tmpdir`
	local errorNumber=`echo "$checkinfo" | grep "LogCheck Right" | awk '{print $5}'`
	if [ 0 -ne $errorNumber ]; then
		echo "$checkinfo"
		rm -rf $svn_tmpdir 2>/dev/null
		return 2
	fi
	echo "log check ok"
	rm -rf $svn_tmpdir 2>/dev/null
	return 0
}

main "$@"
