#!/usr/bin/python
# -*- coding:utf8 -*-

import cgi
import cgitb
import cookielib
import base64
import re
import os
import sys
import urllib
import urllib2
try:
    import json
except ImportError:
    import simplejson as json
from urlparse import urljoin
import datetime
#import subprocess
import shelve
#import ConfigParser
import subprocess

cgitb.enable()
#cgitb.enable(display=0, logdir=LOGDIR)

LOGDIR = "/home/sangfor/www/uext/log"
DEBUG = 'true'
#review board 服务器相关设置
RB_USERNAME = "sangfor"
RB_PASSWORD = "sangfor"
RB_SERVER = "http://200.200.103.100"
#用于表示检查通知的字符串
OK_STRING = "OK"

#哪些路径需要检查是否已review
NEED_REVIEW_DIRS = ["VTP/VMP4.0/Alternate/", "VTP/VMP3.0/Trunk/", "VTP/VMP3.1/Trunk/",
    "VTP/VMP3.4/Trunk/source/", "VTP/VMP3.4/Trunk/build/", "VTP/VMP3.5/Trunk/", "VTP/VMP3.5/Vcenter_Trunk/",
    "VTP/VMP3.6/Trunk/",
    "VTP/ASV3.7/Trunk/",
    "VTP/VMP3.4R2/Trunk/source/",
    "VTP/VMP4.1/Alternate/",
    "VTP/aSV4.2/Alternate/",
    "VTP/aSV4.2/Branchs/",
    "VTP/ASV4.3/Alternate/",
    "VTP/ASV4.3/Trunk/",
    "VTP/ASV4.3/buildenv/",
    "VTP/ASV4.3/Vcenter_Trunk/",
    "VTP/aSV4.5/Alternate/",
    "VTP/aSV4.5_SDDC/Alternate/",
	"VTP/aSV4.6/aSV4.6_SDDC/",
	"VTP/aSV4.6/aSV4.6_SDDC_newspaper/",
    "VTP/VMP4.4/Trunk/",
    "VTP/VMP4.5/Trunk/",
    "VTP/VMP4.6/Trunk/",
    "VTP/VMP4.7/Trunk/",
    "VTP/Cloud2.0/Trunk/",
    "VTP/aSV4.6/VMP4.6/Trunk/",
    "VTP/HCI5.0/Alternate/",
    "VTP/HCI5.1/Alternate/",
    "VTP/HCI5.2/",
    "VTP/aSV4.6/aSV4.5_SDDC_5.9",
	"VTP/HCI_ORACLE/",
    "VTP/aCloud2.0/Trunk/",
    "Cloud/XYCloud2.1/Trunk/",
    "Cloud/XYCloud2.1/Branches/"
]

#哪些路径可以使用no review
ALLOW_NO_REVIEW_DIRS = [
    "VTP/VMP3.0/Trunk/src/app_new/vtp-manager/",
    "VTP/VMP3.0/Trunk/src/app/vtp-manager/",
    "VTP/VMP3.0/Trunk/src/app/p2v/windows/bin/",
    "VTP/VMP3.0/Trunk/src/app/p2v/windows/sfp2vdemo/frontpage_original/",
    "VTP/VMP3.0/Trunk/src/app/p2v/windows/sfp2vdemo/frontpage/",
    "VTP/VMP3.1/Trunk/documents/",
    "VTP/VMP3.1/Trunk/source/app/vtp-manager/www/new_webui/",
    "VTP/VMP3.4/Trunk/documents/",
    "VTP/VMP3.4/Trunk/source/app/vtp-manager/www/new_webui/",
    "VTP/VMP3.4R2/Trunk/Documents/",
    "VTP/VMP3.4R2/Trunk/source/app/vtp-manager/www/new_webui/",
    "VTP/VMP3.5/Trunk/documents/",
    "VTP/VMP3.5/Trunk/source/app/vtp-manager/www/new_webui/",
    "VTP/VMP3.5/Vcenter_Trunk/documents/",
    "VTP/VMP3.5/Vcenter_Trunk/source/app/vtp-manager/www/new_webui/",
    "VTP/VMP3.6/Trunk/documents",
    "VTP/VMP3.6/Trunk/source/app/vtp-manager/www/new_webui/",
    "VTP/ASV3.7/Trunk/documents",
    "VTP/ASV3.7/Trunk/source/app/vtp-manager/www/new_webui/",
    "VTP/VMP4.1/Alternate/src/app/vtp-manager/www/new_webui/tests",
    "VTP/ASV4.3/Alternate/src/app/vtp-manager/www/new_webui/",
    "VTP/ASV4.3/Documents",
    "VTP/VMP4.4/Trunk/Documents",
    "VTP/VMP4.4/Trunk/Persional/",
    "VTP/VMP4.4/Trunk/source/app/vtp-manager/www",
    "VTP/VMP4.5/Trunk/Documents",
    "VTP/VMP4.5/Trunk/source/app/vtp-manager/www",
    "VTP/VMP4.5/Trunk/source/packages/spice-0.12.5",
    #"VTP/aCloud2.0/Trunk/Source/build",
    #"VTP/aCloud2.0/Trunk/Source/src",
    #"VTP/Cloud2.0/Trunk/openstack-kilo/horizon",
    "VTP/aCloud2.0/Trunk/openstack-kilo/horizon/openstack_dashboard",
    "VTP/aSV4.5_SDDC/Alternate/doc",
    "VTP/VMP4.6/Trunk/Documents",
    "VTP/aSV4.5/Alternate/doc",
    "VTP/aSV4.6/aSV4.6_SDDC/doc",
    "VTP/aSV4.6/aSV4.5_SDDC_5.9/doc",
    "VTP/HCI5.2/doc",
    "VTP/HCI5.1/Alternate/doc",
    "VTP/VMP4.6/Trunk/source/app/vtp-manager/www",
    "VTP/VMP4.6/Trunk/source/packages/spice-0.12.5",
    "VTP/VMP4.7/Trunk/Documents",
    "VTP/VMP4.7/Trunk/source/app/vtp-manager/www",
    "VTP/VMP4.7/Trunk/source/packages/spice-0.12.5",
    "VTP/aSV4.6/VMP4.6/Trunk/Documents",
    "VTP/aSV4.6/VMP4.6/Trunk/source/app/vtp-manager/www",
    "VTP/aSV4.6/VMP4.6/Trunk/source/packages/spice-0.12.5",
	"VTP/aSV4.2/Branchs/aSV4.2_SDDC_CN_EN/doc",
	"VTP/Cloud2.0/Trunk/website/",
    "Cloud/XYCloud2.1/Branches/SDNDev/",
    "Cloud/XYCloud2.1/Branches/SDN-L3Agent/",
    "Cloud/XYCloud2.1/Branches/SDN-ACL/",
    "Cloud/XYCloud2.1/Branches/Qemu25/",
    "Cloud/XYCloud2.1/Branches/VAFonNova/",
    #"Cloud/XYCloud2.1/Branches/DisasterRecovery/",
]

# 哪些目录的代码需要冻结（限制提交代码上库）
CODE_FREEZE_DIRS = [
    "VTP/Cloud2.0/Trunk/",
]

# 由以下人员审核通过的代码，在代码冻结的情况下仍然可以提交
SUPPER_REVIEWERS=['zzw', 'hhx']

#哪些人可以无限制地使用no review
ALLOW_NO_REVIEW_AUTHORS=['zzw', 'myq', 'whf', 'lixing', 'lifan', 'hlc', 'hhx', 'fxw', 'jyz', 'gwl', 'xiehz', 'wzt', 'wtd', 'cfq']

def get_os_log_dir():
    platform = sys.platform
    if platform.startswith('win'):
        return get_os_conf_dir()
    return LOGDIR

def get_os_temp_dir():
    import tempfile
    return tempfile.gettempdir()

def debug(s):
    if not DEBUG:
        return
    f = open(os.path.join(get_os_log_dir(), 'review-debug.log'), 'at')
    print >>f, str(datetime.datetime.now()), s
    f.close()

class SvnError(StandardError):
    pass

def decode_svnlog(text):
    def repl(matchobj):
        return '%' + hex(int(matchobj.group(1)))[2:]
    return urllib.unquote(re.sub(r'\?\\(\d\d\d)', repl, text))

COOKIE_FILE = os.path.join(get_os_temp_dir(), 'reviewboard-svn-hooks-cookies.txt')
class Opener(object):
    def __init__(self, server, username, password, cookie_file = None):
        self._server = server
        if cookie_file is None:
            cookie_file = COOKIE_FILE
        self._auth = base64.b64encode(username + ':' + password)
        cookie_jar = cookielib.MozillaCookieJar(cookie_file)
        cookie_handler = urllib2.HTTPCookieProcessor(cookie_jar)
        self._opener = urllib2.build_opener(cookie_handler)

    def open(self, path, ext_headers, *a, **k):
        url = urljoin(self._server, path)
        return self.abs_open(url, ext_headers, *a, **k)

    def abs_open(self, url, ext_headers, *a, **k):
        r = urllib2.Request(url)
        for k, v in ext_headers:
            r.add_header(k, v)
        r.add_header('Authorization', 'Basic ' + self._auth)
        try:
            rsp = self._opener.open(r)
            return rsp.read()
        except urllib2.URLError, e:
            raise SvnError(str(e) + "\n may be the review id you privide not exist." + str(url))

# 判断changed_dirs是否已冻结
def is_dir_freeze(changed_dirs):
    for chdir in changed_dirs:
        for need_dir in CODE_FREEZE_DIRS:
            if (chdir.startswith(need_dir)):
                return True
    return False

# 判断审核人是否有审核代码到冻结目录的权限
def allow_commit_to_freeze_dir(ship_it_users):
    for reviewer in ship_it_users:
        if reviewer in SUPPER_REVIEWERS:
            return True
    return False

#判断changed_dirs是否需要review
def is_dir_need_review(changed_dirs):
    for chdir in changed_dirs:
        for need_dir in NEED_REVIEW_DIRS:
            if (chdir.startswith(need_dir)):
                return True
    return False

#判断strdir是否允许no review
def dir_allow_noreview(chdir):
    for allow_dir in ALLOW_NO_REVIEW_DIRS:
        if (chdir.startswith(allow_dir)):
            return True
    return False

#判断用户author对changed_dirs路径是否有权使用no review
def allow_noreview(changed_dirs, author):
    if (ALLOW_NO_REVIEW_AUTHORS.count(author) > 0):
        debug("author " + author + " no need to review")
        return True
    
    for chdir in changed_dirs:
        if (not dir_allow_noreview(chdir)):
            return False
    debug("dirs " + str(changed_dirs) + " no need to review")
    return True

def get_review_id(log):
    rid = re.search(r'(reuse)[ \t]+reviewid[ \t:]+([0-9]+)', log, re.I)
    if rid:
        return [str(rid.group(2)), 'false']

    rid = re.search(r'reviewid[ \t:]+([0-9]+)', log, re.I)
    if rid:
        return [str(rid.group(1)), 'true']

    rid = re.search(r'(no[ \t]*review)', log, re.M | re.I)
    if rid:
        return [ '-1', 'false' ]
    raise SvnError('No review id. please add msg like "reviewid 123" or "reuse reviewid 123" or "no review" in your commit log')

def add_to_rid_db(rid, need_to_check = 'true'):
    USED_RID_DB = shelve.open(os.path.join(LOGDIR, 'rb-svn-hooks-used-rid.db'))
    if (need_to_check == 'true' and USED_RID_DB.has_key(rid)):
        debug('error: rid ' + rid + ' is already used')
        raise SvnError, "review-id(%s) is already used. you may commit with 'reuse reviewid %s'" % (rid, rid)
    debug('add rid ' + rid + ' to rid_db')
    USED_RID_DB[rid] = rid
    USED_RID_DB.sync()
    USED_RID_DB.close()

def check_rb(rb_server, username, password, rid):
    debug("checking rid " + rid + " in reviewboard " + rb_server )
    opener = Opener(rb_server, username, password)

    # get submitter
    path = 'api/review-requests/' + rid + '/'
    rsp = opener.open(path, {})
    review_request = json.loads(rsp)
    #print review_request
    if review_request['stat'] != 'ok':
        debug("error: get " + rb_server + '/' + path + ': return stat is ' +  review_requst['stat'])
        raise SvnError, "greviewid %s , get reviews error, not ok stat" % rid
    submitter = review_request['review_request']['links']['submitter']['title']
    debug("submitter: " + submitter)

    path = 'api/review-requests/' + str(rid) + '/reviews/?start=0&max-results=500'
    rsp = opener.open(path, {})
    reviews = json.loads(rsp)    
    if reviews['stat'] != 'ok':
        raise SvnError, "greviewid %s ,get reviews error, not ok stat" % rid
    #print reviews
    ship_it_users = set()
    for item in reviews['reviews']:
        ship_it = int(item['ship_it'])
        if ship_it:
            ship_it_users.add(item['links']['user']['title'])

    debug("all shit_it users: " + str(ship_it_users))

    if len(ship_it_users) == 0:
        raise SvnError, "reviewid %s ,nobody ship_it yet." % rid

    if len(ship_it_users^set([submitter])) == 0:
        raise SvnError, "Warning: reviewid %s ,only yourself has ship_it yet, someone other's shit_it is needed!" % rid
    
    # add syntex check by wtd@20160910
    syntexcmd = "/home/sangfor/www/uext/cgi-bin/rbjob -r "+str(rid)+" retrive --check log --flog 2>&1"
    checkResult = subprocess.Popen(syntexcmd, shell=True, stdout=subprocess.PIPE).stdout.read()
    if "errors need check" in checkResult:
        raise SvnError, "reviewid %s has syntex errors, %s" % (rid, checkResult)
    debug(syntexcmd + " => " + checkResult)

    return ship_it_users

# 将提交的代码涉及的svn路径change_dir解析为数组
def parse_change_dirs(changed_dirs):
    dirs = changed_dirs.strip().split('\n')
    return [path.strip() for path in dirs]

def main():
    print "Content-Type: text/html"
    print
    form = cgi.FieldStorage()
    if "svnlog" not in form or "author" not in form or "dir_changed" not in form:
        print "bad params"
        return
    svnlog = form.getfirst("svnlog", "")
    author = form.getfirst("author", "")
    dir_changed = parse_change_dirs(form.getfirst("dir_changed", ""))
    debug("\n-----------------------------check begin-----------------------------");
    debug("author: " + author);
    debug("dir_changed: " + str(dir_changed));
    debug("svnlog: " + decode_svnlog(svnlog));
    
    #只有特定的路径需要强制review
    if (not is_dir_need_review(dir_changed)):
        debug("no need to review: " + str(dir_changed))
        print OK_STRING
        return

    try:
        username = RB_USERNAME
        password = RB_PASSWORD
        rb_server = RB_SERVER
        rid, need_to_check = get_review_id(svnlog)
        if(rid == '-1'):
            # -1 means 'noreview' is found in the svn log
            if (not allow_noreview(dir_changed, author)):
                raise SvnError, "you are not allowed to use 'no review'"
        else:
            debug("reviewid is " + rid + ", need to check rid_db? " + need_to_check)
            
            #有人滥用reuse来逃避代码审核，因此将reuse功能禁用掉
            if(need_to_check == 'false'):
                raise SvnError, "'reuse' is forbidden to prevent abuse"
            
            ship_it_users = check_rb(rb_server, username, password, rid)
            
            # 处理冻结的代码路径
            if (is_dir_freeze(dir_changed)):
                debug("freeze dirs:" + str(dir_changed))
                if (not allow_commit_to_freeze_dir(ship_it_users)):
                    debug(username + " tries to commit changes to frozen codes.")
                    raise SvnError, "Sorry, but the codes have been frozen, contact your project manager if you have any questions."
            
            add_to_rid_db(rid, need_to_check)
    except SvnError, e:
        msg = "catch a SvnError with msg:\n" + str(e)
        debug(msg)
        print msg
    except Exception, e:
        msg = "catch a Exception with msg:\n" + str(e)
        debug(msg)
        print msg
    else:
        debug("everything ok")
        print OK_STRING

main()
