#!/usr/bin/python
# -*- coding:utf8 -*-
import os
import sys
import urllib
import urllib2
import datetime
from urlparse import urljoin

def get_os_log_dir():
    platform = sys.platform
    if platform.startswith('win'):
        return get_os_conf_dir()
    return '/var/log'

DEBUG = 'true'

def debug(s):
    if not DEBUG:
        return
    f = open(os.path.join(get_os_log_dir(), 'review', 'debug.log'), 'at')
    print >>f, str(datetime.datetime.now()), s
    f.close()

#请求url获取返回数据
#url = 'http://ip/path/file?key=value'
#params = {"key1": "value1", "key2": "value2"}
def url_request(url, params):
    req = urllib2.Request(url, data = urllib.urlencode(params))
    page = urllib2.urlopen(req)
    result = page.read()
    return result

#在服务端进行相关检查，以方便定制和扩展功能
def check_review(repos, txn, rb_server):
    params = {
        "repos": repos,
        "txn": txn,
        "author": get_svn_author(repos, txn),
        "dir_changed": get_svn_dir_changed(repos, txn),
        "svnlog": get_svn_log(repos, txn)
    }
    url = urljoin(rb_server, '/cgi-bin/uext/check.py')
    return url_request(url, params)

class SvnError(StandardError):
    pass

def get_cmd_output(cmd):
    debug("execute cmd: " + ' '.join(cmd))
    output = os.popen(' '.join(cmd)).read()
    debug("cmd output is: " + output)
    return output

def make_svnlook_cmd(directive, repos, txn):
    def get_svnlook():
        platform = sys.platform
        if platform.startswith('win'):
            return get_cmd_output(['where svnlook']).split('\n')[0].strip()
        return 'svnlook'

    cmd =[get_svnlook(), directive, '-t',  txn, repos]
    return cmd

#获取修改的svn路径
def get_svn_dir_changed(repos, txn):
    svnlook = make_svnlook_cmd('dirs-changed', repos, txn)
    dir_changed = get_cmd_output(svnlook)
    return dir_changed

#获取提交代码的用户名
def get_svn_author(repos, txn):
    svnlook = make_svnlook_cmd('author', repos, txn)
    author = get_cmd_output(svnlook).split('\n')[0].strip()
    return author

#获取提交的svn日志
def get_svn_log(repos, txn):
    svnlook = make_svnlook_cmd('log', repos, txn)
    log = get_cmd_output(svnlook)
    return log

def main():
    debug('\ncommand:' + str(sys.argv))
    if len(sys.argv) != 4:
        print >> sys.stderr, "Usage: python simple-svn-hooks.py repo txn rb_server_url"
        sys.exit(1)

    try:
        repos = sys.argv[1]
        txn = sys.argv[2]
        rb_server = sys.argv[3]

        result = check_review(repos, txn, rb_server)
        if (result.strip() != 'OK'):
            raise SvnError, result

    except SvnError, e:
        debug("catch a SvnError with msg:\n" + str(e))
        print >> sys.stderr, str(e)
        debug("exit code: 1")
        sys.exit(1)
    except Exception, e:
        debug("catch a Exception with msg:\n" + str(e))
        print >> sys.stderr, str(e)
        import traceback
        traceback.print_exc(file=sys.stderr)
        debug("exit code: 1")
        sys.exit(1)
    else:
        debug("everything ok, exit code: 0")
        sys.exit(0)

if __name__ == "__main__":
    main()
