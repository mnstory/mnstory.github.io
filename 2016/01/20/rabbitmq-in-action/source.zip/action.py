# coding=utf-8
import os
import json

class Action(object):
    def __init__(self):
        print "Action init"

    def onAppsCheck(self, data): 
        return 0, 'apps check all ok', nil

    def process(self, request):
        if request['action'] == "AppsCheck" :
            (status, msg, data) = self.onAppsCheck(request['data'])
        else:
            (status, msg, data) = (1, "undefined action " + str(request['action']), None)
        return {'status': status, 'action':request['action'], 'msg': msg, 'data' : data}
