#!/usr/bin/env python
# coding=utf-8
import json
import pika
import action

class Connection(object):
    def __init__(self, userToken, nodeIdentify, nodeType, action):
        self.userToken = userToken
        self.nodeIdentify = nodeIdentify
        self.nodeType = nodeType

        # connect
        credentials = pika.PlainCredentials('username', 'password')
        self.connection = pika.BlockingConnection(pika.ConnectionParameters('server', credentials=credentials))
        # get channels
        self.channel = self.connection.channel()

        self.init()
        self.action = action

    def init(self):
        self.nodeQueue  = "user.{0}.{1}".format(self.userToken, self.nodeIdentify)

        #self.channel.exchange_declare(exchange='al', exchange_type='direct')
        self.channel.queue_declare(queue=self.nodeQueue)
        #self.channel.queue_bind(exchange='al', queue=self.nodeQueue, routing_key=self.nodeQueue)

        # for send back
        self.channel.exchange_declare(exchange='al', exchange_type='direct')

    def report(self, msg):
        self.channel.basic_publish(exchange='al', routing_key="center.queue", body=msg)

    def onMessage(self, channel, method_frame, header_frame, body):
        print str(method_frame.delivery_tag) + ":" + body

        # deal
        try:
            request = json.loads(body);
        except(ValueError):
            print "not json format"
            self.channel.basic_ack(delivery_tag=method_frame.delivery_tag)
            return False;

        # continue
        result = self.action.process(request)
        response = json.dumps(result);
        self.report(response)
        print str(method_frame.delivery_tag) + ":" + body + " -> " + response

        self.channel.basic_ack(delivery_tag=method_frame.delivery_tag)

    def run(self):
        print "start consuming on " + self.nodeQueue
        self.channel.basic_consume(self.onMessage, self.nodeQueue)
        try:
            self.channel.start_consuming()
        except KeyboardInterrupt:
            self.channel.stop_consuming()

    def __del__(self):
        self.connection.close()

def entry():
    conn = Connection(1, 'node1', args.type, action.Action())
    conn.run()

entry()
