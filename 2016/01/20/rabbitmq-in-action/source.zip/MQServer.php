<?php

namespace App\Console\Commands;

//define('AMQP_DEBUG', true);

use Illuminate\Console\Command;
use PhpAmqpLib\Connection\AMQPStreamConnection;
use PhpAmqpLib\Message\AMQPMessage;
use App\Opr;
use App\Node;

class MQServer extends Command
{
	private $exchange_name = 'al';

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
	protected $signature = 'mq
							{route=center.queue : which route?}
							{msg=listen : messages want to send, "listen" means listen on route}
							{--ex= : Whether the send to exchange}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'use MQ to send message, or listen on server queue at center.queue';


    public function __construct()
    {
        parent::__construct();
	    $this->connection = new AMQPStreamConnection('server', 5672, 'username', 'password');
	    $this->channel = $this->connection->channel();
    }

	public function __destruct()
	{
		$this->channel->close();
		$this->connection->close();
	}

	function onNodeReport($user, $params) {
		$user_id = $user['token']; //TODO CHECK USER VAILD
		$params['user_id'] = $user_id;

		$node = new Node;
		$node->updateInsert($params);
	}

	function dispatchMessage($request) {
		print_r($request);
		if(isset($request['cookies'])){
			$cookies = $request['cookies'];
			if(isset($cookies['opr'])) {
				$opr = Opr::find($cookies['opr']);
				if($opr) {
					if (0 != $request['status']) {
						$opr->fail($request['msg']);
						return true;
					} else if(isset($request['data']) && isset($request['data']['percent'])) {
						$opr->updatePercent($request['data']['percent'], $request['data']['desc']);
						return true;
					} else {
						if (method_exists(Opr::class, 'on'.$opr['name'].'Response')) {
							call_user_func_array(array(Opr::class, 'on'.$opr['name'].'Response'), array($opr, $request['data']));
							return true;
						} else {
							$this->error("unexist opr Response for ".$opr['name']);
						}
					}
				} else {
					$this->error("unknow opr by id " .$cookies['opr']);
				}
				return false;
			}
		}

		$data = $request['data'];
		if (!$data) {
			$this->warn($request['msg']." with empty data");
			return true;
		}

		if (method_exists($this, 'on'.$data['action'])) {
			 call_user_func_array(array($this, 'on'.$data['action']), array($data['user'], $data['params']));
		}
	}

	function server($route) {
		// declare a queue to consume
		$this->channel->exchange_declare($this->exchange_name, 'direct', false, false, false);
		list($queue_name, ,) = $this->channel->queue_declare("", false, false, true, false);

		// bind queue to exchange and set route filter
		$this->channel->queue_bind($queue_name, $this->exchange_name, $route);

		$callback = function($msg){
			$this->info(' [x] '. $msg->delivery_info['routing_key']. ':'. $msg->body);
			$request = json_decode($msg->body, true);
			$this->dispatchMessage($request);
		};

		$this->channel->basic_consume($queue_name, '', false, false, false, false, $callback);
		$this->info("listen on queue $queue_name, exchange $this->exchange_name, route $route");

		while(count($this->channel->callbacks)) {
			$this->channel->wait();
		}
		$this->warn("exit listen $route!");
	}

	function client($route, $msg, $exchange = '') {
		if(!empty($exchange)) {
			$this->channel->exchange_declare($exchange, 'direct', false, false, false);
		}
		$this->channel->basic_publish(new AMQPMessage($msg), $exchange, $route);
		$this->info("$exchange $route -> $msg");
	}

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
	    $route = $this->argument('route');
	    $msg = $this->argument('msg');
		$exchange = $this->option('ex');

	    if('listen' == $msg) {
		    $this->server($route);
	    } else {
		    //php artisan mq "user.1.00163e0213fe" "hello world"
		    $this->client($route, $msg, $exchange);
	    }
    }
}
