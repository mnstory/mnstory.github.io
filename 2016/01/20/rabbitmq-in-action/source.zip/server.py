# coding=utf-8

import pika
import alcommon

class Connection(object):
    def __init__(self):
        # connect
        credentials = pika.PlainCredentials('username', 'password')
        self.connection = pika.BlockingConnection(pika.ConnectionParameters('server', credentials=credentials))
        # get channels
        self.channel = self.connection.channel()
        self.init()

    def init(self):
        self.channel.exchange_declare(exchange='al', exchange_type='direct')
        # use anonymous queue
        self.queue = self.channel.queue_declare(exclusive=True)
        # bind queue to exchange
        self.channel.queue_bind(exchange='al', queue=self.queue.method.queue, routing_key="center.queue")

    def onMessage(self, channel, method_frame, header_frame, body):
        print(str(method_frame.delivery_tag) + ":" + body)
        # TODO: deal messages
        self.channel.basic_ack(delivery_tag=method_frame.delivery_tag)

    def run(self):
        print "start consuming on queue" + self.queue.method.queue + ", exchange 'al', route 'center.queue'"
        self.channel.basic_consume(self.onMessage, self.queue.method.queue)
        try:
            self.channel.start_consuming()
        except KeyboardInterrupt:
            self.channel.stop_consuming()

    def __del__(self):
        self.connection.close()

conn = Connection()
conn.run()